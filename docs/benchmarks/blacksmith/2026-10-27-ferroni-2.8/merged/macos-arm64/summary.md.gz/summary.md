# Ferriki regex modes: macos-arm64

Commit: ee1ad3a881544112f659c4b3d83eddca263bfd02. Node: v24.21.0.
comparison: Apple M4 Pro (Virtual) (6 cores).
curated: Apple M4 Pro (Virtual) (6 cores).
tiobe: Apple M4 Pro (Virtual) (6 cores).

Source Off, Auto (lazy DFA), Eager and prepared Eager are separate contenders. Source contenders do not open prepared archives. All contenders share each corpus VM and rotate within timing rounds. Prepared groups are used only where standard packages exist; custom-only grammars retain source fallback.

Warm medians reuse highlighters. First use includes imports, setup and one repository corpus render in a fresh process; downloads and process creation are excluded. Diagnostics are captured outside timed calls and confirm policy/archive use, not complete group coverage.

| Workload | Ferriki source Off | Ferriki source Auto (lazy DFA) | Ferriki source Eager | Ferriki prepared Eager | Shiki WASM | Shiki JS | Prism (independent grammars) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Repository / warm ms | 134.790 | 87.390 | 88.340 | 84.108 | 367.890 | unsupported | unsupported |
| Repository / first use ms | 206.392 | 318.520 | 388.980 | 194.824 | 1072.396 | unsupported | unsupported |
| curated / TypeScript / example ms | 1.662 | 0.713 | 0.682 | 0.689 | 3.583 | 5.150 | 0.196 |
| curated / TypeScript / large ms | 24.133 | 9.406 | 9.256 | 9.378 | 52.574 | 77.152 | 2.208 |
| curated / TSX / example ms | 1.773 | 0.802 | 0.769 | 0.781 | 4.134 | 4.271 | 0.294 |
| curated / TSX / large ms | 31.862 | 13.676 | 13.308 | 13.690 | 72.018 | 79.131 | 4.353 |
| curated / Rust / example ms | 0.260 | 0.208 | 0.198 | 0.198 | 1.436 | 0.612 | 0.124 |
| curated / Rust / large ms | 3.382 | 2.831 | 2.830 | 2.824 | 21.851 | 8.961 | 1.403 |
| curated / CSS / example ms | 0.328 | 0.382 | 0.366 | 0.370 | 3.019 | 0.654 | 0.094 |
| curated / CSS / large ms | 3.855 | 4.086 | 4.190 | 3.924 | 44.395 | 8.498 | 1.068 |
| curated / HTML / example ms | 1.329 | 0.946 | 0.932 | 0.931 | 4.255 | 3.324 | 0.274 |
| curated / HTML / large ms | 16.827 | 9.236 | 9.654 | 9.525 | 62.033 | 45.524 | 2.807 |
| curated / C++ / example ms | 1.183 | 0.606 | 0.573 | 0.570 | 3.209 | 2.773 | 0.125 |
| curated / C++ / large ms | 14.142 | 5.798 | 5.721 | 5.655 | 44.848 | 37.768 | 1.263 |
| curated / Swift / example ms | 0.390 | 0.252 | 0.242 | 0.240 | 1.620 | 0.855 | 0.089 |
| curated / Swift / large ms | 5.279 | 3.328 | 3.191 | 3.081 | 23.377 | 11.512 | 1.104 |
| curated / Java / example ms | 0.243 | 0.184 | 0.179 | 0.181 | 1.030 | 0.646 | 0.096 |
| curated / Java / large ms | 3.528 | 2.588 | 2.571 | 2.595 | 15.627 | 9.719 | 1.382 |
| curated / Markdown / example ms | 0.553 | 0.429 | 0.409 | 0.406 | 1.399 | 1.910 | 0.159 |
| curated / Markdown / large ms | 4.947 | 3.579 | 3.551 | 3.513 | 15.790 | 23.378 | 1.512 |
| curated / TOML / example ms | 0.074 | 0.073 | 0.075 | 0.075 | 0.181 | 0.135 | 0.032 |
| curated / TOML / large ms | 1.119 | 1.094 | 1.122 | 1.123 | 2.762 | 2.017 | 0.509 |
| curated / YAML / example ms | 0.983 | 1.225 | 1.228 | 1.228 | 1.245 | unsupported | 0.045 |
| curated / YAML / large ms | 15.472 | 19.563 | 19.396 | 19.500 | 19.896 | unsupported | 0.670 |
| curated / JSON / example ms | 0.119 | 0.117 | 0.131 | 0.130 | 0.294 | 0.239 | 0.050 |
| curated / JSON / large ms | 1.900 | 1.850 | 2.042 | 2.007 | 4.844 | 3.910 | 0.818 |
| curated / Astro / example ms | 2.072 | 1.402 | 1.585 | 1.374 | 5.083 | 4.759 | unsupported |
| curated / Astro / large ms | 20.850 | 12.735 | 15.613 | 12.789 | 54.279 | 53.313 | unsupported |
| curated / Svelte / example ms | 2.230 | 1.339 | 1.405 | 1.295 | 5.232 | 6.044 | unsupported |
| curated / Svelte / large ms | 30.735 | 15.595 | 17.761 | 15.744 | 75.535 | 90.268 | unsupported |
| curated / Ruby / example ms | 0.212 | 0.151 | 0.151 | 0.151 | 1.580 | 0.675 | 0.088 |
| curated / Ruby / large ms | 3.175 | 2.257 | 2.312 | 2.277 | 24.429 | 10.292 | 1.291 |
| curated / Python / example ms | 0.320 | 0.256 | 0.245 | 0.248 | 1.558 | 0.865 | 0.119 |
| curated / Python / large ms | 4.453 | 3.590 | 3.554 | 3.541 | 23.485 | 12.661 | 1.577 |
| curated / Vue / example ms | 1.188 | 0.641 | 0.630 | 0.636 | 2.165 | 2.420 | unsupported |
| curated / Vue / large ms | 16.546 | 7.761 | 7.605 | 7.703 | 30.777 | 33.657 | unsupported |
| curated / MDX / example ms | 0.658 | 0.426 | 0.402 | 0.397 | 2.003 | 2.934 | unsupported |
| curated / MDX / large ms | 7.824 | 4.861 | 4.708 | 4.594 | 27.239 | 42.075 | unsupported |
| curated / SCSS / example ms | 0.287 | 0.255 | 0.245 | 0.238 | 3.047 | 0.597 | 0.153 |
| curated / SCSS / large ms | 3.987 | 3.317 | 3.248 | 3.154 | 48.411 | 8.566 | 2.080 |
| curated / Bash / example ms | 0.322 | 0.272 | 0.266 | 0.265 | 0.981 | 0.635 | 0.109 |
| curated / Bash / large ms | 4.649 | 3.996 | 3.908 | 3.914 | 14.813 | 9.331 | 1.509 |
| tiobe / Python / example ms | 0.315 | 0.256 | 0.249 | 0.249 | 1.508 | 0.835 | 0.114 |
| tiobe / Python / large ms | 4.404 | 3.546 | 3.489 | 3.506 | 22.960 | 12.472 | 1.522 |
| tiobe / C / example ms | 0.382 | 0.207 | 0.198 | 0.205 | 1.657 | 0.890 | 0.087 |
| tiobe / C / large ms | 5.530 | 2.889 | 2.845 | 2.860 | 25.807 | 13.685 | 1.224 |
| tiobe / C++ / example ms | 1.132 | 0.579 | 0.557 | 0.555 | 3.036 | 2.521 | 0.114 |
| tiobe / C++ / large ms | 13.175 | 5.378 | 5.412 | 5.288 | 43.082 | 34.520 | 1.202 |
| tiobe / Java / example ms | 0.230 | 0.172 | 0.168 | 0.169 | 1.001 | 0.610 | 0.089 |
| tiobe / Java / large ms | 3.424 | 2.566 | 2.504 | 2.502 | 15.515 | 9.432 | 1.305 |
| tiobe / C# / example ms | 0.790 | 0.293 | 0.285 | 0.279 | 1.185 | 1.818 | 0.187 |
| tiobe / C# / large ms | 11.874 | 3.819 | 3.810 | 3.745 | 16.539 | 28.519 | 2.509 |
| tiobe / JavaScript / example ms | 2.218 | 1.063 | 1.015 | 1.057 | 5.088 | 5.877 | 0.250 |
| tiobe / JavaScript / large ms | 32.192 | 11.567 | 11.581 | 11.540 | 77.915 | 96.156 | 2.572 |
| tiobe / Visual Basic / example ms | 0.272 | 0.295 | 0.294 | 0.287 | 1.070 | 0.375 | 0.061 |
| tiobe / Visual Basic / large ms | 3.915 | 3.969 | 3.986 | 3.931 | 15.853 | 5.274 | 0.789 |
| tiobe / SQL / example ms | 0.245 | 0.233 | 0.230 | 0.229 | 2.358 | 0.385 | 0.069 |
| tiobe / SQL / large ms | 3.757 | 3.607 | 3.592 | 3.623 | 38.163 | 5.842 | 1.001 |
| tiobe / R / example ms | 0.197 | 0.153 | 0.151 | 0.150 | 1.484 | 0.657 | 0.051 |
| tiobe / R / large ms | 2.907 | 2.260 | 2.269 | 2.258 | 23.274 | 9.917 | 0.771 |
| tiobe / Rust / example ms | 0.184 | 0.150 | 0.147 | 0.148 | 1.135 | 0.463 | 0.082 |
| tiobe / Rust / large ms | 2.782 | 2.290 | 2.275 | 2.289 | 17.411 | 6.718 | 1.179 |
| tiobe / Fortran / example ms | 0.557 | 0.506 | 0.505 | 0.481 | 1.817 | 1.137 | 0.073 |
| tiobe / Fortran / large ms | 6.430 | 4.910 | 5.066 | 4.746 | 25.264 | 15.461 | 0.891 |
| tiobe / Go / example ms | 0.350 | 0.232 | 0.227 | 0.219 | 1.297 | 0.553 | 0.061 |
| tiobe / Go / large ms | 4.964 | 3.240 | 3.215 | 3.035 | 19.318 | 7.850 | 0.835 |
| tiobe / Delphi/Object Pascal / example ms | 0.110 | 0.139 | 0.138 | 0.135 | 0.736 | 0.200 | 0.061 |
| tiobe / Delphi/Object Pascal / large ms | 1.750 | 2.243 | 2.249 | 2.217 | 11.693 | 3.133 | 0.972 |
| tiobe / PHP / example ms | 0.520 | 0.368 | 0.360 | 0.365 | 2.118 | 0.844 | 0.186 |
| tiobe / PHP / large ms | 4.158 | 2.653 | 2.664 | 2.641 | 26.185 | 9.099 | 1.834 |
| tiobe / Assembly language / example ms | 0.262 | 0.114 | 0.108 | 0.108 | 2.239 | 0.767 | 0.033 |
| tiobe / Assembly language / large ms | 3.575 | 1.455 | 1.395 | 1.388 | 35.497 | 11.223 | 0.409 |
| tiobe / Ada / example ms | 0.198 | 0.193 | 0.191 | 0.186 | 0.645 | 0.406 | 0.071 |
| tiobe / Ada / large ms | 2.762 | 2.697 | 2.687 | 2.631 | 9.689 | 6.144 | 1.092 |
| tiobe / Swift / example ms | 0.357 | 0.235 | 0.228 | 0.223 | 1.445 | 0.759 | 0.079 |
| tiobe / Swift / large ms | 4.738 | 2.907 | 2.840 | 2.773 | 21.147 | 10.562 | 1.013 |
| tiobe / Objective-C / example ms | 0.401 | 0.239 | 0.234 | 0.224 | 1.807 | 0.782 | 0.076 |
| tiobe / Objective-C / large ms | 5.213 | 2.865 | 2.845 | 2.756 | 27.442 | 11.381 | 0.945 |
| tiobe / COBOL / example ms | 0.772 | 0.739 | 0.722 | 0.724 | 4.431 | 0.657 | 0.085 |
| tiobe / COBOL / large ms | 10.887 | 10.748 | 10.634 | 10.621 | 69.619 | 9.115 | 1.036 |

All required exact native/Shiki HTML checks and regex-mode diagnostics passed. Prism uses independent grammars and has no TextMate parity claim.

