# Ferriki regex modes: linux-x86-64

Commit: ee1ad3a881544112f659c4b3d83eddca263bfd02. Node: v24.21.0.
comparison: AMD EPYC (4 cores).
curated: AMD EPYC (4 cores).
tiobe: AMD EPYC (4 cores).

Source Off, Auto (lazy DFA), Eager and prepared Eager are separate contenders. Source contenders do not open prepared archives. All contenders share each corpus VM and rotate within timing rounds. Prepared groups are used only where standard packages exist; custom-only grammars retain source fallback.

Warm medians reuse highlighters. First use includes imports, setup and one repository corpus render in a fresh process; downloads and process creation are excluded. Diagnostics are captured outside timed calls and confirm policy/archive use, not complete group coverage.

| Workload | Ferriki source Off | Ferriki source Auto (lazy DFA) | Ferriki source Eager | Ferriki prepared Eager | Shiki WASM | Shiki JS | Prism (independent grammars) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Repository / warm ms | 121.554 | 85.080 | 85.402 | 81.121 | 303.549 | unsupported | unsupported |
| Repository / first use ms | 224.610 | 368.633 | 476.549 | 227.895 | 954.098 | unsupported | unsupported |
| curated / TypeScript / example ms | 1.734 | 0.759 | 0.732 | 0.721 | 3.534 | 4.370 | 0.199 |
| curated / TypeScript / large ms | 25.967 | 10.990 | 10.771 | 10.817 | 54.955 | 67.496 | 2.052 |
| curated / TSX / example ms | 1.909 | 0.899 | 0.870 | 0.867 | 4.042 | 3.866 | 0.304 |
| curated / TSX / large ms | 28.695 | 13.310 | 13.264 | 13.367 | 63.891 | 59.977 | 3.583 |
| curated / Rust / example ms | 0.256 | 0.196 | 0.186 | 0.182 | 1.245 | 0.584 | 0.103 |
| curated / Rust / large ms | 3.344 | 2.777 | 2.766 | 2.743 | 18.566 | 8.070 | 1.065 |
| curated / CSS / example ms | 0.332 | 0.319 | 0.305 | 0.291 | 2.431 | 0.654 | 0.080 |
| curated / CSS / large ms | 4.115 | 4.371 | 4.351 | 4.196 | 37.331 | 9.541 | 0.976 |
| curated / HTML / example ms | 1.120 | 0.690 | 0.665 | 0.650 | 3.294 | 2.515 | 0.223 |
| curated / HTML / large ms | 16.026 | 9.629 | 9.641 | 9.616 | 52.068 | 38.742 | 2.816 |
| curated / C++ / example ms | 1.128 | 0.504 | 0.486 | 0.461 | 2.693 | 2.688 | 0.108 |
| curated / C++ / large ms | 15.943 | 6.761 | 6.748 | 6.549 | 39.805 | 38.860 | 1.055 |
| curated / Swift / example ms | 0.433 | 0.268 | 0.247 | 0.238 | 1.447 | 0.883 | 0.086 |
| curated / Swift / large ms | 5.422 | 3.426 | 3.293 | 3.219 | 21.568 | 11.981 | 0.948 |
| curated / Java / example ms | 0.326 | 0.225 | 0.208 | 0.205 | 1.101 | 0.725 | 0.104 |
| curated / Java / large ms | 3.966 | 2.932 | 2.871 | 2.863 | 15.855 | 9.796 | 1.161 |
| curated / Markdown / example ms | 0.489 | 0.342 | 0.322 | 0.307 | 1.154 | 1.541 | 0.151 |
| curated / Markdown / large ms | 5.941 | 4.407 | 4.330 | 4.162 | 16.651 | 22.453 | 1.406 |
| curated / TOML / example ms | 0.093 | 0.085 | 0.087 | 0.086 | 0.213 | 0.169 | 0.031 |
| curated / TOML / large ms | 1.287 | 1.249 | 1.282 | 1.265 | 3.218 | 2.554 | 0.442 |
| curated / YAML / example ms | 1.213 | 1.513 | 1.497 | 1.485 | 1.290 | unsupported | 0.061 |
| curated / YAML / large ms | 17.753 | 23.778 | 23.737 | 23.764 | 19.022 | unsupported | 0.561 |
| curated / JSON / example ms | 0.144 | 0.136 | 0.156 | 0.154 | 0.350 | 0.297 | 0.050 |
| curated / JSON / large ms | 2.248 | 2.175 | 2.473 | 2.459 | 5.407 | 4.675 | 0.731 |
| curated / Astro / example ms | 2.175 | 1.527 | 1.797 | 1.450 | 4.419 | 3.981 | unsupported |
| curated / Astro / large ms | 25.527 | 18.273 | 22.919 | 17.985 | 53.446 | 50.750 | unsupported |
| curated / Svelte / example ms | 2.093 | 1.246 | 1.377 | 1.169 | 4.508 | 4.613 | unsupported |
| curated / Svelte / large ms | 30.375 | 16.767 | 19.527 | 16.862 | 68.713 | 71.342 | unsupported |
| curated / Ruby / example ms | 0.313 | 0.201 | 0.194 | 0.194 | 1.587 | 0.807 | 0.115 |
| curated / Ruby / large ms | 3.699 | 2.693 | 2.682 | 2.690 | 23.938 | 10.737 | 1.270 |
| curated / Python / example ms | 0.412 | 0.303 | 0.281 | 0.276 | 1.623 | 0.980 | 0.129 |
| curated / Python / large ms | 5.052 | 4.120 | 4.027 | 4.006 | 24.082 | 13.611 | 1.507 |
| curated / Vue / example ms | 1.221 | 0.645 | 0.622 | 0.602 | 2.051 | 2.126 | unsupported |
| curated / Vue / large ms | 17.855 | 9.080 | 9.002 | 8.905 | 32.284 | 33.573 | unsupported |
| curated / MDX / example ms | 0.695 | 0.425 | 0.398 | 0.379 | 1.759 | 2.359 | unsupported |
| curated / MDX / large ms | 9.109 | 5.646 | 5.434 | 5.348 | 26.726 | 36.550 | unsupported |
| curated / SCSS / example ms | 0.340 | 0.255 | 0.237 | 0.229 | 2.528 | 0.649 | 0.129 |
| curated / SCSS / large ms | 4.091 | 3.351 | 3.319 | 3.185 | 39.039 | 8.734 | 1.541 |
| curated / Bash / example ms | 0.399 | 0.305 | 0.290 | 0.283 | 0.993 | 0.707 | 0.121 |
| curated / Bash / large ms | 5.003 | 4.110 | 4.098 | 4.058 | 13.872 | 9.671 | 1.320 |
| tiobe / Python / example ms | 0.411 | 0.304 | 0.284 | 0.278 | 1.619 | 0.985 | 0.130 |
| tiobe / Python / large ms | 5.053 | 4.105 | 4.061 | 4.004 | 24.124 | 13.611 | 1.493 |
| tiobe / C / example ms | 0.485 | 0.247 | 0.229 | 0.224 | 1.695 | 1.003 | 0.094 |
| tiobe / C / large ms | 6.233 | 3.225 | 3.177 | 3.129 | 25.168 | 14.210 | 1.127 |
| tiobe / C++ / example ms | 1.129 | 0.501 | 0.481 | 0.454 | 2.701 | 2.661 | 0.110 |
| tiobe / C++ / large ms | 15.752 | 6.786 | 6.689 | 6.495 | 40.014 | 39.184 | 1.111 |
| tiobe / Java / example ms | 0.326 | 0.225 | 0.208 | 0.205 | 1.113 | 0.736 | 0.105 |
| tiobe / Java / large ms | 3.908 | 2.872 | 2.848 | 2.806 | 16.077 | 10.169 | 1.209 |
| tiobe / C# / example ms | 0.917 | 0.334 | 0.317 | 0.306 | 1.240 | 1.683 | 0.220 |
| tiobe / C# / large ms | 12.935 | 4.318 | 4.247 | 4.179 | 17.649 | 24.209 | 2.502 |
| tiobe / JavaScript / example ms | 2.067 | 0.828 | 0.798 | 0.788 | 4.417 | 4.582 | 0.233 |
| tiobe / JavaScript / large ms | 31.326 | 12.010 | 11.889 | 11.978 | 69.163 | 70.480 | 2.264 |
| tiobe / Visual Basic / example ms | 0.317 | 0.294 | 0.287 | 0.276 | 0.987 | 0.412 | 0.057 |
| tiobe / Visual Basic / large ms | 4.296 | 4.114 | 4.145 | 4.058 | 14.643 | 5.894 | 0.739 |
| tiobe / SQL / example ms | 0.322 | 0.279 | 0.266 | 0.259 | 2.038 | 0.482 | 0.074 |
| tiobe / SQL / large ms | 4.042 | 3.787 | 3.776 | 3.745 | 31.098 | 6.346 | 0.895 |
| tiobe / R / example ms | 0.270 | 0.195 | 0.186 | 0.181 | 1.461 | 0.766 | 0.055 |
| tiobe / R / large ms | 3.358 | 2.654 | 2.659 | 2.622 | 22.238 | 10.824 | 0.738 |
| tiobe / Rust / example ms | 0.253 | 0.197 | 0.185 | 0.183 | 1.254 | 0.591 | 0.103 |
| tiobe / Rust / large ms | 3.273 | 2.749 | 2.724 | 2.717 | 18.966 | 8.303 | 1.068 |
| tiobe / Fortran / example ms | 0.632 | 0.435 | 0.417 | 0.409 | 1.751 | 1.176 | 0.073 |
| tiobe / Fortran / large ms | 8.287 | 6.083 | 6.008 | 5.972 | 26.233 | 17.127 | 0.808 |
| tiobe / Go / example ms | 0.447 | 0.286 | 0.266 | 0.257 | 1.374 | 0.694 | 0.069 |
| tiobe / Go / large ms | 5.644 | 3.635 | 3.587 | 3.447 | 20.068 | 9.202 | 0.779 |
| tiobe / Delphi/Object Pascal / example ms | 0.144 | 0.179 | 0.168 | 0.160 | 0.762 | 0.263 | 0.074 |
| tiobe / Delphi/Object Pascal / large ms | 1.937 | 2.307 | 2.270 | 2.226 | 11.652 | 3.868 | 0.899 |
| tiobe / PHP / example ms | 0.390 | 0.232 | 0.218 | 0.211 | 1.676 | 0.781 | 0.156 |
| tiobe / PHP / large ms | 4.724 | 2.929 | 2.907 | 2.844 | 25.553 | 10.089 | 1.553 |
| tiobe / Assembly language / example ms | 0.310 | 0.135 | 0.118 | 0.112 | 2.217 | 0.899 | 0.038 |
| tiobe / Assembly language / large ms | 3.718 | 1.582 | 1.523 | 1.521 | 33.887 | 12.170 | 0.364 |
| tiobe / Ada / example ms | 0.263 | 0.233 | 0.223 | 0.212 | 0.756 | 0.517 | 0.078 |
| tiobe / Ada / large ms | 3.168 | 3.005 | 2.981 | 2.930 | 10.707 | 7.124 | 1.065 |
| tiobe / Swift / example ms | 0.434 | 0.267 | 0.247 | 0.238 | 1.474 | 0.898 | 0.087 |
| tiobe / Swift / large ms | 5.453 | 3.455 | 3.297 | 3.205 | 22.362 | 12.309 | 0.973 |
| tiobe / Objective-C / example ms | 0.470 | 0.248 | 0.233 | 0.220 | 1.756 | 0.931 | 0.077 |
| tiobe / Objective-C / large ms | 5.875 | 3.184 | 3.148 | 3.076 | 26.587 | 12.995 | 0.922 |
| tiobe / COBOL / example ms | 0.810 | 0.723 | 0.711 | 0.701 | 3.547 | 0.756 | 0.081 |
| tiobe / COBOL / large ms | 11.206 | 10.836 | 10.803 | 10.731 | 55.682 | 9.735 | 0.917 |

All required exact native/Shiki HTML checks and regex-mode diagnostics passed. Prism uses independent grammars and has no TextMate parity claim.

