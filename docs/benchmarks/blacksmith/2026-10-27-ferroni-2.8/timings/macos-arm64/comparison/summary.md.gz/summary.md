# Ferriki regex modes: macos-arm64

Commit: ee1ad3a881544112f659c4b3d83eddca263bfd02. Node: v24.21.0.
CPU: Apple M4 Pro (Virtual) (6 cores).

Source Off, Auto (lazy DFA), Eager and prepared Eager are separate contenders. Source contenders do not open prepared archives. All contenders share each corpus VM and rotate within timing rounds. Prepared groups are used only where standard packages exist; custom-only grammars retain source fallback.

Warm medians reuse highlighters. First use includes imports, setup and one repository corpus render in a fresh process; downloads and process creation are excluded. Diagnostics are captured outside timed calls and confirm policy/archive use, not complete group coverage.

| Workload | Ferriki source Off | Ferriki source Auto (lazy DFA) | Ferriki source Eager | Ferriki prepared Eager | Shiki WASM | Shiki JS | Prism (independent grammars) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Repository / warm ms | 134.790 | 87.390 | 88.340 | 84.108 | 367.890 | unsupported | unsupported |
| Repository / first use ms | 206.392 | 318.520 | 388.980 | 194.824 | 1072.396 | unsupported | unsupported |

All required exact native/Shiki HTML checks and regex-mode diagnostics passed. Prism uses independent grammars and has no TextMate parity claim.

