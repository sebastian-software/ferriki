# Ferriki regex modes: macos-arm64

Commit: ee1ad3a881544112f659c4b3d83eddca263bfd02. Node: v24.21.0.
CPU: Apple M4 Pro (Virtual) (6 cores).

Source Off, Auto (lazy DFA), Eager and prepared Eager are separate contenders. Source contenders do not open prepared archives. All contenders share each corpus VM and rotate within timing rounds. Prepared groups are used only where standard packages exist; custom-only grammars retain source fallback.

Warm medians reuse highlighters. First use includes imports, setup and one repository corpus render in a fresh process; downloads and process creation are excluded. Diagnostics are captured outside timed calls and confirm policy/archive use, not complete group coverage.

| Workload | Ferriki source Off | Ferriki source Auto (lazy DFA) | Ferriki source Eager | Ferriki prepared Eager | Shiki WASM | Shiki JS | Prism (independent grammars) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| curated / TypeScript / example ms | 1.662 | 0.713 | 0.682 | 0.689 | 3.583 | 5.150 | 0.196 |
| curated / TypeScript / large ms | 24.133 | 9.406 | 9.256 | 9.378 | 52.574 | 77.152 | 2.208 |
| curated / TSX / example ms | 1.773 | 0.802 | 0.769 | 0.781 | 4.134 | 4.271 | 0.294 |
| curated / TSX / large ms | 31.862 | 13.676 | 13.308 | 13.690 | 72.018 | 79.131 | 4.353 |
| curated / Rust / example ms | 0.260 | 0.208 | 0.198 | 0.198 | 1.436 | 0.612 | 0.124 |
| curated / Rust / large ms | 3.382 | 2.831 | 2.830 | 2.824 | 21.851 | 8.961 | 1.403 |
| curated / CSS / example ms | 0.328 | 0.382 | 0.366 | 0.370 | 3.019 | 0.654 | 0.094 |
| curated / CSS / large ms | 3.855 | 4.086 | 4.190 | 3.924 | 44.395 | 8.498 | 1.068 |
| curated / HTML / example ms | 1.329 | 0.946 | 0.932 | 0.931 | 4.255 | 3.324 | 0.274 |
| curated / HTML / large ms | 16.827 | 9.236 | 9.654 | 9.525 | 62.033 | 45.524 | 2.807 |
| curated / C++ / example ms | 1.183 | 0.606 | 0.573 | 0.570 | 3.209 | 2.773 | 0.125 |
| curated / C++ / large ms | 14.142 | 5.798 | 5.721 | 5.655 | 44.848 | 37.768 | 1.263 |
| curated / Swift / example ms | 0.390 | 0.252 | 0.242 | 0.240 | 1.620 | 0.855 | 0.089 |
| curated / Swift / large ms | 5.279 | 3.328 | 3.191 | 3.081 | 23.377 | 11.512 | 1.104 |
| curated / Java / example ms | 0.243 | 0.184 | 0.179 | 0.181 | 1.030 | 0.646 | 0.096 |
| curated / Java / large ms | 3.528 | 2.588 | 2.571 | 2.595 | 15.627 | 9.719 | 1.382 |
| curated / Markdown / example ms | 0.553 | 0.429 | 0.409 | 0.406 | 1.399 | 1.910 | 0.159 |
| curated / Markdown / large ms | 4.947 | 3.579 | 3.551 | 3.513 | 15.790 | 23.378 | 1.512 |
| curated / TOML / example ms | 0.074 | 0.073 | 0.075 | 0.075 | 0.181 | 0.135 | 0.032 |
| curated / TOML / large ms | 1.119 | 1.094 | 1.122 | 1.123 | 2.762 | 2.017 | 0.509 |
| curated / YAML / example ms | 0.983 | 1.225 | 1.228 | 1.228 | 1.245 | unsupported | 0.045 |
| curated / YAML / large ms | 15.472 | 19.563 | 19.396 | 19.500 | 19.896 | unsupported | 0.670 |
| curated / JSON / example ms | 0.119 | 0.117 | 0.131 | 0.130 | 0.294 | 0.239 | 0.050 |
| curated / JSON / large ms | 1.900 | 1.850 | 2.042 | 2.007 | 4.844 | 3.910 | 0.818 |
| curated / Astro / example ms | 2.072 | 1.402 | 1.585 | 1.374 | 5.083 | 4.759 | unsupported |
| curated / Astro / large ms | 20.850 | 12.735 | 15.613 | 12.789 | 54.279 | 53.313 | unsupported |
| curated / Svelte / example ms | 2.230 | 1.339 | 1.405 | 1.295 | 5.232 | 6.044 | unsupported |
| curated / Svelte / large ms | 30.735 | 15.595 | 17.761 | 15.744 | 75.535 | 90.268 | unsupported |
| curated / Ruby / example ms | 0.212 | 0.151 | 0.151 | 0.151 | 1.580 | 0.675 | 0.088 |
| curated / Ruby / large ms | 3.175 | 2.257 | 2.312 | 2.277 | 24.429 | 10.292 | 1.291 |
| curated / Python / example ms | 0.320 | 0.256 | 0.245 | 0.248 | 1.558 | 0.865 | 0.119 |
| curated / Python / large ms | 4.453 | 3.590 | 3.554 | 3.541 | 23.485 | 12.661 | 1.577 |
| curated / Vue / example ms | 1.188 | 0.641 | 0.630 | 0.636 | 2.165 | 2.420 | unsupported |
| curated / Vue / large ms | 16.546 | 7.761 | 7.605 | 7.703 | 30.777 | 33.657 | unsupported |
| curated / MDX / example ms | 0.658 | 0.426 | 0.402 | 0.397 | 2.003 | 2.934 | unsupported |
| curated / MDX / large ms | 7.824 | 4.861 | 4.708 | 4.594 | 27.239 | 42.075 | unsupported |
| curated / SCSS / example ms | 0.287 | 0.255 | 0.245 | 0.238 | 3.047 | 0.597 | 0.153 |
| curated / SCSS / large ms | 3.987 | 3.317 | 3.248 | 3.154 | 48.411 | 8.566 | 2.080 |
| curated / Bash / example ms | 0.322 | 0.272 | 0.266 | 0.265 | 0.981 | 0.635 | 0.109 |
| curated / Bash / large ms | 4.649 | 3.996 | 3.908 | 3.914 | 14.813 | 9.331 | 1.509 |

All required exact native/Shiki HTML checks and regex-mode diagnostics passed. Prism uses independent grammars and has no TextMate parity claim.

