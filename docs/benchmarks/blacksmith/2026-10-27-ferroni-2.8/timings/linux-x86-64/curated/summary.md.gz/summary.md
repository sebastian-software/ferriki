# Ferriki regex modes: linux-x86-64

Commit: ee1ad3a881544112f659c4b3d83eddca263bfd02. Node: v24.21.0.
CPU: AMD EPYC (4 cores).

Source Off, Auto (lazy DFA), Eager and prepared Eager are separate contenders. Source contenders do not open prepared archives. All contenders share each corpus VM and rotate within timing rounds. Prepared groups are used only where standard packages exist; custom-only grammars retain source fallback.

Warm medians reuse highlighters. First use includes imports, setup and one repository corpus render in a fresh process; downloads and process creation are excluded. Diagnostics are captured outside timed calls and confirm policy/archive use, not complete group coverage.

| Workload | Ferriki source Off | Ferriki source Auto (lazy DFA) | Ferriki source Eager | Ferriki prepared Eager | Shiki WASM | Shiki JS | Prism (independent grammars) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| curated / TypeScript / example ms | 1.734 | 0.759 | 0.732 | 0.721 | 3.534 | 4.370 | 0.199 |
| curated / TypeScript / large ms | 25.967 | 10.990 | 10.771 | 10.817 | 54.955 | 67.496 | 2.052 |
| curated / TSX / example ms | 1.909 | 0.899 | 0.870 | 0.867 | 4.042 | 3.866 | 0.304 |
| curated / TSX / large ms | 28.695 | 13.310 | 13.264 | 13.367 | 63.891 | 59.977 | 3.583 |
| curated / Rust / example ms | 0.256 | 0.196 | 0.186 | 0.182 | 1.245 | 0.584 | 0.103 |
| curated / Rust / large ms | 3.344 | 2.777 | 2.766 | 2.743 | 18.566 | 8.070 | 1.065 |
| curated / CSS / example ms | 0.332 | 0.319 | 0.305 | 0.291 | 2.431 | 0.654 | 0.080 |
| curated / CSS / large ms | 4.115 | 4.371 | 4.351 | 4.196 | 37.331 | 9.541 | 0.976 |
| curated / HTML / example ms | 1.120 | 0.690 | 0.665 | 0.650 | 3.294 | 2.515 | 0.223 |
| curated / HTML / large ms | 16.026 | 9.629 | 9.641 | 9.616 | 52.068 | 38.742 | 2.816 |
| curated / C++ / example ms | 1.128 | 0.504 | 0.486 | 0.461 | 2.693 | 2.688 | 0.108 |
| curated / C++ / large ms | 15.943 | 6.761 | 6.748 | 6.549 | 39.805 | 38.860 | 1.055 |
| curated / Swift / example ms | 0.433 | 0.268 | 0.247 | 0.238 | 1.447 | 0.883 | 0.086 |
| curated / Swift / large ms | 5.422 | 3.426 | 3.293 | 3.219 | 21.568 | 11.981 | 0.948 |
| curated / Java / example ms | 0.326 | 0.225 | 0.208 | 0.205 | 1.101 | 0.725 | 0.104 |
| curated / Java / large ms | 3.966 | 2.932 | 2.871 | 2.863 | 15.855 | 9.796 | 1.161 |
| curated / Markdown / example ms | 0.489 | 0.342 | 0.322 | 0.307 | 1.154 | 1.541 | 0.151 |
| curated / Markdown / large ms | 5.941 | 4.407 | 4.330 | 4.162 | 16.651 | 22.453 | 1.406 |
| curated / TOML / example ms | 0.093 | 0.085 | 0.087 | 0.086 | 0.213 | 0.169 | 0.031 |
| curated / TOML / large ms | 1.287 | 1.249 | 1.282 | 1.265 | 3.218 | 2.554 | 0.442 |
| curated / YAML / example ms | 1.213 | 1.513 | 1.497 | 1.485 | 1.290 | unsupported | 0.061 |
| curated / YAML / large ms | 17.753 | 23.778 | 23.737 | 23.764 | 19.022 | unsupported | 0.561 |
| curated / JSON / example ms | 0.144 | 0.136 | 0.156 | 0.154 | 0.350 | 0.297 | 0.050 |
| curated / JSON / large ms | 2.248 | 2.175 | 2.473 | 2.459 | 5.407 | 4.675 | 0.731 |
| curated / Astro / example ms | 2.175 | 1.527 | 1.797 | 1.450 | 4.419 | 3.981 | unsupported |
| curated / Astro / large ms | 25.527 | 18.273 | 22.919 | 17.985 | 53.446 | 50.750 | unsupported |
| curated / Svelte / example ms | 2.093 | 1.246 | 1.377 | 1.169 | 4.508 | 4.613 | unsupported |
| curated / Svelte / large ms | 30.375 | 16.767 | 19.527 | 16.862 | 68.713 | 71.342 | unsupported |
| curated / Ruby / example ms | 0.313 | 0.201 | 0.194 | 0.194 | 1.587 | 0.807 | 0.115 |
| curated / Ruby / large ms | 3.699 | 2.693 | 2.682 | 2.690 | 23.938 | 10.737 | 1.270 |
| curated / Python / example ms | 0.412 | 0.303 | 0.281 | 0.276 | 1.623 | 0.980 | 0.129 |
| curated / Python / large ms | 5.052 | 4.120 | 4.027 | 4.006 | 24.082 | 13.611 | 1.507 |
| curated / Vue / example ms | 1.221 | 0.645 | 0.622 | 0.602 | 2.051 | 2.126 | unsupported |
| curated / Vue / large ms | 17.855 | 9.080 | 9.002 | 8.905 | 32.284 | 33.573 | unsupported |
| curated / MDX / example ms | 0.695 | 0.425 | 0.398 | 0.379 | 1.759 | 2.359 | unsupported |
| curated / MDX / large ms | 9.109 | 5.646 | 5.434 | 5.348 | 26.726 | 36.550 | unsupported |
| curated / SCSS / example ms | 0.340 | 0.255 | 0.237 | 0.229 | 2.528 | 0.649 | 0.129 |
| curated / SCSS / large ms | 4.091 | 3.351 | 3.319 | 3.185 | 39.039 | 8.734 | 1.541 |
| curated / Bash / example ms | 0.399 | 0.305 | 0.290 | 0.283 | 0.993 | 0.707 | 0.121 |
| curated / Bash / large ms | 5.003 | 4.110 | 4.098 | 4.058 | 13.872 | 9.671 | 1.320 |

All required exact native/Shiki HTML checks and regex-mode diagnostics passed. Prism uses independent grammars and has no TextMate parity claim.

