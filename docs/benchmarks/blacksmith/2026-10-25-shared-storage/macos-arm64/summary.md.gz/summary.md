# Ferriki regex modes: macos-arm64

Commit: 0477eed2bd6f7a7e3fdf148937fd6dde42e7b3d8. Node: v24.21.0.
comparison: Apple M4 Pro (Virtual) (6 cores).
curated: Apple M4 Pro (Virtual) (6 cores).
tiobe: Apple M4 Pro (Virtual) (6 cores).

Source Off, Auto (lazy DFA), Eager and prepared Eager are separate contenders. Source contenders do not open prepared archives. All contenders share each corpus VM and rotate within timing rounds. Prepared groups are used only where standard packages exist; custom-only grammars retain source fallback.

Warm medians reuse highlighters. First use includes imports, setup and one repository corpus render in a fresh process; downloads and process creation are excluded. Diagnostics are captured outside timed calls and confirm policy/archive use, not complete group coverage.

| Workload | Ferriki source Off | Ferriki source Auto (lazy DFA) | Ferriki source Eager | Ferriki prepared Eager | Shiki WASM | Shiki JS | Prism (independent grammars) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Repository / warm ms | 121.731 | 82.331 | 82.833 | 78.525 | 338.214 | unsupported | unsupported |
| Repository / first use ms | 242.731 | 369.427 | 452.502 | 277.198 | 1224.893 | unsupported | unsupported |
| curated / TypeScript / example ms | 2.115 | 1.135 | 1.076 | 1.105 | 4.606 | 6.630 | 0.286 |
| curated / TypeScript / large ms | 25.344 | 9.785 | 9.588 | 9.689 | 57.472 | 82.667 | 2.535 |
| curated / TSX / example ms | 1.890 | 0.918 | 0.875 | 0.897 | 4.348 | 4.616 | 0.324 |
| curated / TSX / large ms | 31.587 | 13.813 | 13.591 | 13.392 | 73.160 | 79.523 | 4.402 |
| curated / Rust / example ms | 0.214 | 0.174 | 0.169 | 0.166 | 1.250 | 0.523 | 0.101 |
| curated / Rust / large ms | 3.177 | 2.657 | 2.598 | 2.582 | 20.048 | 8.389 | 1.408 |
| curated / CSS / example ms | 0.426 | 0.533 | 0.513 | 0.522 | 3.616 | 0.789 | 0.116 |
| curated / CSS / large ms | 4.454 | 4.686 | 4.747 | 4.580 | 52.599 | 9.926 | 1.310 |
| curated / HTML / example ms | 1.160 | 0.802 | 0.777 | 0.797 | 3.762 | 2.811 | 0.234 |
| curated / HTML / large ms | 15.158 | 8.556 | 8.638 | 8.482 | 56.467 | 40.109 | 2.685 |
| curated / C++ / example ms | 1.120 | 0.518 | 0.518 | 0.496 | 3.181 | 2.675 | 0.120 |
| curated / C++ / large ms | 15.126 | 6.218 | 6.039 | 6.134 | 47.480 | 40.344 | 1.298 |
| curated / Swift / example ms | 0.392 | 0.249 | 0.239 | 0.239 | 1.660 | 0.877 | 0.092 |
| curated / Swift / large ms | 5.362 | 3.350 | 3.383 | 3.117 | 24.456 | 12.726 | 1.218 |
| curated / Java / example ms | 0.280 | 0.207 | 0.200 | 0.201 | 1.171 | 0.748 | 0.113 |
| curated / Java / large ms | 4.213 | 3.112 | 3.028 | 3.066 | 18.060 | 11.568 | 1.604 |
| curated / Markdown / example ms | 0.338 | 0.249 | 0.239 | 0.233 | 1.022 | 1.425 | 0.116 |
| curated / Markdown / large ms | 4.596 | 3.311 | 3.236 | 3.237 | 15.236 | 22.029 | 1.427 |
| curated / TOML / example ms | 0.074 | 0.072 | 0.073 | 0.073 | 0.177 | 0.133 | 0.030 |
| curated / TOML / large ms | 1.059 | 1.051 | 1.076 | 1.073 | 2.704 | 1.968 | 0.476 |
| curated / YAML / example ms | 0.977 | 1.213 | 1.206 | 1.208 | 1.236 | unsupported | 0.045 |
| curated / YAML / large ms | 14.929 | 18.702 | 18.867 | 18.825 | 19.614 | unsupported | 0.639 |
| curated / JSON / example ms | 0.132 | 0.127 | 0.143 | 0.142 | 0.328 | 0.269 | 0.055 |
| curated / JSON / large ms | 2.213 | 2.121 | 2.337 | 2.336 | 5.663 | 4.561 | 0.928 |
| curated / Astro / example ms | 2.431 | 1.641 | 1.856 | 1.618 | 5.975 | 6.023 | unsupported |
| curated / Astro / large ms | 22.623 | 14.517 | 18.077 | 15.171 | 61.833 | 62.786 | unsupported |
| curated / Svelte / example ms | 2.359 | 1.406 | 1.478 | 1.354 | 5.667 | 6.381 | unsupported |
| curated / Svelte / large ms | 30.479 | 15.809 | 17.949 | 15.957 | 77.386 | 88.102 | unsupported |
| curated / Ruby / example ms | 0.246 | 0.175 | 0.172 | 0.172 | 1.714 | 0.771 | 0.105 |
| curated / Ruby / large ms | 3.620 | 2.586 | 2.542 | 2.588 | 28.381 | 12.558 | 1.459 |
| curated / Python / example ms | 0.297 | 0.237 | 0.230 | 0.232 | 1.486 | 0.829 | 0.112 |
| curated / Python / large ms | 4.416 | 3.544 | 3.461 | 3.564 | 23.447 | 12.712 | 1.543 |
| curated / Vue / example ms | 1.208 | 0.636 | 0.607 | 0.622 | 2.194 | 2.426 | unsupported |
| curated / Vue / large ms | 17.980 | 8.509 | 8.480 | 8.548 | 33.347 | 38.145 | unsupported |
| curated / MDX / example ms | 0.550 | 0.361 | 0.345 | 0.344 | 1.745 | 2.540 | unsupported |
| curated / MDX / large ms | 7.388 | 4.809 | 4.528 | 4.407 | 25.339 | 39.508 | unsupported |
| curated / SCSS / example ms | 0.293 | 0.275 | 0.262 | 0.261 | 2.912 | 0.580 | 0.152 |
| curated / SCSS / large ms | 3.648 | 3.028 | 2.976 | 2.886 | 44.237 | 7.791 | 1.936 |
| curated / Bash / example ms | 0.281 | 0.237 | 0.232 | 0.233 | 0.859 | 0.567 | 0.091 |
| curated / Bash / large ms | 4.313 | 3.681 | 3.638 | 3.650 | 13.341 | 8.822 | 1.390 |
| tiobe / Python / example ms | 0.318 | 0.253 | 0.248 | 0.246 | 1.552 | 0.890 | 0.122 |
| tiobe / Python / large ms | 4.272 | 3.464 | 3.367 | 3.362 | 22.010 | 11.991 | 1.491 |
| tiobe / C / example ms | 0.345 | 0.175 | 0.171 | 0.174 | 1.565 | 0.852 | 0.079 |
| tiobe / C / large ms | 5.192 | 2.729 | 2.713 | 2.709 | 24.438 | 13.298 | 1.128 |
| tiobe / C++ / example ms | 0.897 | 0.381 | 0.369 | 0.360 | 2.648 | 2.176 | 0.098 |
| tiobe / C++ / large ms | 13.091 | 5.419 | 5.311 | 5.270 | 40.592 | 33.619 | 1.168 |
| tiobe / Java / example ms | 0.223 | 0.161 | 0.158 | 0.160 | 0.973 | 0.606 | 0.087 |
| tiobe / Java / large ms | 3.745 | 2.813 | 2.862 | 2.749 | 17.033 | 10.614 | 1.420 |
| tiobe / C# / example ms | 0.888 | 0.311 | 0.302 | 0.297 | 1.353 | 2.058 | 0.218 |
| tiobe / C# / large ms | 13.698 | 4.507 | 4.436 | 4.385 | 20.183 | 34.014 | 2.904 |
| tiobe / JavaScript / example ms | 2.420 | 1.100 | 1.047 | 1.067 | 5.571 | 6.818 | 0.283 |
| tiobe / JavaScript / large ms | 33.780 | 11.799 | 11.844 | 12.173 | 78.930 | 96.433 | 2.654 |
| tiobe / Visual Basic / example ms | 0.236 | 0.232 | 0.234 | 0.231 | 0.965 | 0.316 | 0.049 |
| tiobe / Visual Basic / large ms | 3.694 | 3.741 | 3.749 | 3.695 | 15.177 | 4.888 | 0.746 |
| tiobe / SQL / example ms | 0.228 | 0.221 | 0.218 | 0.217 | 2.271 | 0.364 | 0.063 |
| tiobe / SQL / large ms | 3.613 | 3.480 | 3.438 | 3.445 | 36.372 | 5.623 | 0.932 |
| tiobe / R / example ms | 0.181 | 0.140 | 0.140 | 0.140 | 1.448 | 0.626 | 0.047 |
| tiobe / R / large ms | 2.731 | 2.150 | 2.158 | 2.154 | 22.589 | 9.500 | 0.705 |
| tiobe / Rust / example ms | 0.171 | 0.140 | 0.138 | 0.140 | 1.043 | 0.421 | 0.075 |
| tiobe / Rust / large ms | 2.669 | 2.216 | 2.190 | 2.214 | 16.594 | 6.601 | 1.132 |
| tiobe / Fortran / example ms | 0.483 | 0.373 | 0.383 | 0.354 | 1.733 | 1.077 | 0.069 |
| tiobe / Fortran / large ms | 7.636 | 5.799 | 5.856 | 5.442 | 29.622 | 17.886 | 0.980 |
| tiobe / Go / example ms | 0.466 | 0.323 | 0.302 | 0.291 | 1.663 | 0.734 | 0.085 |
| tiobe / Go / large ms | 6.070 | 3.898 | 3.874 | 3.676 | 23.942 | 9.906 | 0.959 |
| tiobe / Delphi/Object Pascal / example ms | 0.147 | 0.205 | 0.199 | 0.194 | 0.909 | 0.259 | 0.085 |
| tiobe / Delphi/Object Pascal / large ms | 1.931 | 2.436 | 2.425 | 2.390 | 13.128 | 3.479 | 1.040 |
| tiobe / PHP / example ms | 0.454 | 0.295 | 0.277 | 0.272 | 2.076 | 0.849 | 0.194 |
| tiobe / PHP / large ms | 4.348 | 2.805 | 2.702 | 2.696 | 27.333 | 10.020 | 1.872 |
| tiobe / Assembly language / example ms | 0.271 | 0.119 | 0.112 | 0.111 | 2.355 | 0.860 | 0.037 |
| tiobe / Assembly language / large ms | 3.766 | 1.487 | 1.434 | 1.460 | 37.595 | 12.085 | 0.419 |
| tiobe / Ada / example ms | 0.213 | 0.202 | 0.201 | 0.194 | 0.712 | 0.453 | 0.079 |
| tiobe / Ada / large ms | 3.163 | 2.963 | 2.930 | 3.040 | 11.302 | 7.244 | 1.182 |
| tiobe / Swift / example ms | 0.437 | 0.277 | 0.264 | 0.264 | 1.766 | 0.943 | 0.102 |
| tiobe / Swift / large ms | 5.152 | 3.158 | 3.057 | 3.037 | 23.337 | 11.596 | 1.108 |
| tiobe / Objective-C / example ms | 0.389 | 0.214 | 0.207 | 0.200 | 1.832 | 0.807 | 0.077 |
| tiobe / Objective-C / large ms | 5.845 | 3.125 | 3.187 | 2.972 | 30.679 | 13.161 | 1.025 |
| tiobe / COBOL / example ms | 0.859 | 0.796 | 0.777 | 0.771 | 4.824 | 0.756 | 0.099 |
| tiobe / COBOL / large ms | 11.203 | 11.171 | 11.517 | 11.146 | 72.780 | 9.188 | 1.044 |

All required exact native/Shiki HTML checks and regex-mode diagnostics passed. Prism uses independent grammars and has no TextMate parity claim.

