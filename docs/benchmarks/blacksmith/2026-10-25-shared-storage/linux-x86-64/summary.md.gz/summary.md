# Ferriki regex modes: linux-x86-64

Commit: 0477eed2bd6f7a7e3fdf148937fd6dde42e7b3d8. Node: v24.21.0.
comparison: AMD EPYC (4 cores).
curated: AMD EPYC (4 cores).
tiobe: AMD EPYC (4 cores).

Source Off, Auto (lazy DFA), Eager and prepared Eager are separate contenders. Source contenders do not open prepared archives. All contenders share each corpus VM and rotate within timing rounds. Prepared groups are used only where standard packages exist; custom-only grammars retain source fallback.

Warm medians reuse highlighters. First use includes imports, setup and one repository corpus render in a fresh process; downloads and process creation are excluded. Diagnostics are captured outside timed calls and confirm policy/archive use, not complete group coverage.

| Workload | Ferriki source Off | Ferriki source Auto (lazy DFA) | Ferriki source Eager | Ferriki prepared Eager | Shiki WASM | Shiki JS | Prism (independent grammars) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Repository / warm ms | 120.028 | 84.023 | 84.410 | 79.956 | 297.829 | unsupported | unsupported |
| Repository / first use ms | 215.555 | 357.030 | 446.017 | 469.832 | 947.019 | unsupported | unsupported |
| curated / TypeScript / example ms | 1.724 | 0.752 | 0.728 | 0.720 | 3.600 | 4.403 | 0.198 |
| curated / TypeScript / large ms | 25.761 | 10.954 | 10.760 | 10.759 | 55.765 | 67.745 | 2.150 |
| curated / TSX / example ms | 1.898 | 0.909 | 0.879 | 0.872 | 4.092 | 3.904 | 0.309 |
| curated / TSX / large ms | 28.546 | 13.363 | 13.218 | 13.301 | 64.165 | 60.421 | 3.612 |
| curated / Rust / example ms | 0.252 | 0.197 | 0.187 | 0.181 | 1.244 | 0.583 | 0.103 |
| curated / Rust / large ms | 3.269 | 2.748 | 2.738 | 2.694 | 18.705 | 8.107 | 1.092 |
| curated / CSS / example ms | 0.332 | 0.323 | 0.309 | 0.291 | 2.425 | 0.658 | 0.081 |
| curated / CSS / large ms | 4.163 | 4.455 | 4.462 | 4.224 | 37.136 | 9.292 | 0.929 |
| curated / HTML / example ms | 1.099 | 0.680 | 0.663 | 0.635 | 3.278 | 2.504 | 0.219 |
| curated / HTML / large ms | 15.861 | 9.702 | 9.815 | 9.616 | 52.076 | 39.140 | 2.833 |
| curated / C++ / example ms | 1.130 | 0.501 | 0.491 | 0.456 | 2.723 | 2.738 | 0.107 |
| curated / C++ / large ms | 15.843 | 6.778 | 6.743 | 6.499 | 40.182 | 39.263 | 1.110 |
| curated / Swift / example ms | 0.432 | 0.269 | 0.248 | 0.235 | 1.451 | 0.890 | 0.086 |
| curated / Swift / large ms | 5.378 | 3.455 | 3.310 | 3.138 | 21.453 | 12.270 | 1.024 |
| curated / Java / example ms | 0.323 | 0.224 | 0.208 | 0.204 | 1.109 | 0.725 | 0.103 |
| curated / Java / large ms | 3.851 | 2.854 | 2.798 | 2.774 | 16.166 | 10.006 | 1.254 |
| curated / Markdown / example ms | 0.485 | 0.339 | 0.319 | 0.301 | 1.162 | 1.568 | 0.147 |
| curated / Markdown / large ms | 6.039 | 4.401 | 4.325 | 4.176 | 16.778 | 23.019 | 1.390 |
| curated / TOML / example ms | 0.093 | 0.086 | 0.088 | 0.086 | 0.213 | 0.167 | 0.031 |
| curated / TOML / large ms | 1.286 | 1.258 | 1.299 | 1.259 | 3.109 | 2.442 | 0.439 |
| curated / YAML / example ms | 1.208 | 1.509 | 1.492 | 1.478 | 1.296 | unsupported | 0.061 |
| curated / YAML / large ms | 17.762 | 23.752 | 23.793 | 23.727 | 19.224 | unsupported | 0.562 |
| curated / JSON / example ms | 0.143 | 0.135 | 0.157 | 0.152 | 0.350 | 0.296 | 0.050 |
| curated / JSON / large ms | 2.225 | 2.150 | 2.486 | 2.414 | 5.420 | 4.654 | 0.740 |
| curated / Astro / example ms | 2.004 | 1.357 | 1.610 | 1.260 | 4.448 | 3.946 | unsupported |
| curated / Astro / large ms | 22.801 | 15.539 | 20.167 | 15.349 | 54.466 | 51.476 | unsupported |
| curated / Svelte / example ms | 2.058 | 1.222 | 1.347 | 1.143 | 4.567 | 4.670 | unsupported |
| curated / Svelte / large ms | 29.912 | 16.661 | 19.373 | 16.634 | 69.337 | 71.223 | unsupported |
| curated / Ruby / example ms | 0.308 | 0.201 | 0.195 | 0.187 | 1.616 | 0.809 | 0.114 |
| curated / Ruby / large ms | 3.644 | 2.670 | 2.712 | 2.625 | 24.581 | 10.795 | 1.330 |
| curated / Python / example ms | 0.405 | 0.300 | 0.281 | 0.271 | 1.622 | 0.979 | 0.129 |
| curated / Python / large ms | 4.965 | 4.052 | 3.986 | 3.915 | 24.164 | 13.551 | 1.519 |
| curated / Vue / example ms | 1.204 | 0.637 | 0.616 | 0.593 | 2.094 | 2.195 | unsupported |
| curated / Vue / large ms | 17.662 | 9.112 | 8.968 | 8.809 | 32.170 | 33.471 | unsupported |
| curated / MDX / example ms | 0.685 | 0.417 | 0.395 | 0.372 | 1.786 | 2.388 | unsupported |
| curated / MDX / large ms | 9.137 | 5.685 | 5.508 | 5.337 | 26.823 | 36.548 | unsupported |
| curated / SCSS / example ms | 0.339 | 0.261 | 0.244 | 0.228 | 2.540 | 0.645 | 0.129 |
| curated / SCSS / large ms | 4.074 | 3.353 | 3.292 | 3.071 | 39.772 | 8.779 | 1.557 |
| curated / Bash / example ms | 0.395 | 0.303 | 0.289 | 0.280 | 0.989 | 0.702 | 0.121 |
| curated / Bash / large ms | 4.811 | 4.022 | 4.026 | 3.961 | 13.790 | 9.734 | 1.305 |
| tiobe / Python / example ms | 0.437 | 0.323 | 0.302 | 0.294 | 1.734 | 1.088 | 0.145 |
| tiobe / Python / large ms | 5.481 | 4.438 | 4.359 | 4.277 | 25.533 | 15.029 | 1.747 |
| tiobe / C / example ms | 0.516 | 0.259 | 0.242 | 0.236 | 1.797 | 1.106 | 0.103 |
| tiobe / C / large ms | 6.754 | 3.422 | 3.393 | 3.310 | 26.705 | 15.795 | 1.375 |
| tiobe / C++ / example ms | 1.209 | 0.544 | 0.529 | 0.493 | 2.916 | 2.931 | 0.119 |
| tiobe / C++ / large ms | 16.869 | 7.173 | 7.198 | 6.947 | 42.281 | 41.431 | 1.200 |
| tiobe / Java / example ms | 0.344 | 0.238 | 0.222 | 0.218 | 1.175 | 0.804 | 0.113 |
| tiobe / Java / large ms | 4.273 | 3.121 | 3.095 | 3.055 | 17.027 | 11.086 | 1.344 |
| tiobe / C# / example ms | 0.971 | 0.352 | 0.337 | 0.324 | 1.310 | 1.790 | 0.233 |
| tiobe / C# / large ms | 13.876 | 4.729 | 4.669 | 4.558 | 18.866 | 25.771 | 2.607 |
| tiobe / JavaScript / example ms | 2.205 | 0.899 | 0.865 | 0.853 | 4.716 | 4.976 | 0.258 |
| tiobe / JavaScript / large ms | 33.116 | 12.801 | 12.663 | 12.729 | 73.194 | 76.344 | 2.363 |
| tiobe / Visual Basic / example ms | 0.339 | 0.316 | 0.310 | 0.297 | 1.059 | 0.460 | 0.063 |
| tiobe / Visual Basic / large ms | 4.615 | 4.438 | 4.492 | 4.387 | 15.624 | 6.398 | 0.795 |
| tiobe / SQL / example ms | 0.345 | 0.295 | 0.284 | 0.275 | 2.134 | 0.540 | 0.080 |
| tiobe / SQL / large ms | 4.250 | 4.009 | 4.005 | 3.992 | 32.368 | 7.282 | 1.059 |
| tiobe / R / example ms | 0.287 | 0.206 | 0.199 | 0.192 | 1.558 | 0.812 | 0.059 |
| tiobe / R / large ms | 3.648 | 2.898 | 2.905 | 2.827 | 23.590 | 11.598 | 0.786 |
| tiobe / Rust / example ms | 0.270 | 0.209 | 0.199 | 0.194 | 1.330 | 0.636 | 0.110 |
| tiobe / Rust / large ms | 3.581 | 2.987 | 2.991 | 2.958 | 19.961 | 8.918 | 1.132 |
| tiobe / Fortran / example ms | 0.664 | 0.457 | 0.444 | 0.430 | 1.852 | 1.260 | 0.076 |
| tiobe / Fortran / large ms | 8.779 | 6.578 | 6.473 | 6.427 | 27.534 | 18.559 | 0.852 |
| tiobe / Go / example ms | 0.471 | 0.301 | 0.283 | 0.272 | 1.445 | 0.750 | 0.074 |
| tiobe / Go / large ms | 5.975 | 3.817 | 3.775 | 3.589 | 21.101 | 10.009 | 0.862 |
| tiobe / Delphi/Object Pascal / example ms | 0.152 | 0.188 | 0.178 | 0.170 | 0.816 | 0.299 | 0.081 |
| tiobe / Delphi/Object Pascal / large ms | 2.110 | 2.497 | 2.442 | 2.396 | 12.382 | 4.450 | 0.979 |
| tiobe / PHP / example ms | 0.414 | 0.246 | 0.231 | 0.219 | 1.778 | 0.852 | 0.172 |
| tiobe / PHP / large ms | 5.086 | 3.146 | 3.121 | 2.994 | 26.473 | 11.040 | 1.687 |
| tiobe / Assembly language / example ms | 0.331 | 0.144 | 0.127 | 0.121 | 2.322 | 0.952 | 0.042 |
| tiobe / Assembly language / large ms | 3.982 | 1.686 | 1.637 | 1.634 | 35.349 | 12.810 | 0.397 |
| tiobe / Ada / example ms | 0.281 | 0.246 | 0.237 | 0.224 | 0.823 | 0.585 | 0.084 |
| tiobe / Ada / large ms | 3.512 | 3.281 | 3.263 | 3.180 | 11.725 | 8.146 | 1.093 |
| tiobe / Swift / example ms | 0.456 | 0.278 | 0.258 | 0.250 | 1.538 | 0.966 | 0.093 |
| tiobe / Swift / large ms | 5.812 | 3.628 | 3.477 | 3.369 | 22.976 | 13.442 | 1.074 |
| tiobe / Objective-C / example ms | 0.510 | 0.264 | 0.251 | 0.236 | 1.882 | 1.026 | 0.085 |
| tiobe / Objective-C / large ms | 6.503 | 3.525 | 3.514 | 3.397 | 28.765 | 14.318 | 1.047 |
| tiobe / COBOL / example ms | 0.856 | 0.770 | 0.756 | 0.744 | 3.713 | 0.816 | 0.089 |
| tiobe / COBOL / large ms | 11.941 | 11.549 | 11.491 | 11.358 | 57.064 | 10.717 | 1.005 |

All required exact native/Shiki HTML checks and regex-mode diagnostics passed. Prism uses independent grammars and has no TextMate parity claim.

