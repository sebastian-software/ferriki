# Ferriki regex modes: macos-arm64

Commit: 8aba6dd009fa09a3eed895e1764b2f04dbef0f1b. Node: v24.21.0.
CPU: Apple M4 Pro (Virtual) (6 cores).

Source Off, Auto (lazy DFA), Eager and prepared Eager are separate contenders. Source contenders do not open prepared archives. All contenders share each corpus VM and rotate within timing rounds. Prepared groups are used only where standard packages exist; custom-only grammars retain source fallback.

Warm medians reuse highlighters. First use includes imports, setup and one repository corpus render in a fresh process; downloads and process creation are excluded. Diagnostics are captured outside timed calls and confirm policy/archive use, not complete group coverage.

| Workload | Ferriki source Off | Ferriki source Auto (lazy DFA) | Ferriki source Eager | Ferriki prepared Eager | Shiki WASM | Shiki JS | Prism (independent grammars) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| tiobe / Python / example ms | 0.306 | 0.248 | 0.241 | 0.242 | 1.529 | 0.848 | 0.115 |
| tiobe / Python / large ms | 4.405 | 3.601 | 3.513 | 3.486 | 22.734 | 12.403 | 1.527 |
| tiobe / C / example ms | 0.395 | 0.211 | 0.202 | 0.208 | 1.743 | 0.979 | 0.098 |
| tiobe / C / large ms | 5.371 | 2.820 | 2.777 | 2.794 | 24.938 | 13.507 | 1.185 |
| tiobe / C++ / example ms | 0.980 | 0.444 | 0.436 | 0.429 | 2.800 | 2.280 | 0.103 |
| tiobe / C++ / large ms | 13.136 | 5.399 | 5.238 | 5.249 | 40.997 | 33.656 | 1.181 |
| tiobe / Java / example ms | 0.222 | 0.162 | 0.158 | 0.159 | 0.970 | 0.607 | 0.087 |
| tiobe / Java / large ms | 3.464 | 2.602 | 2.527 | 2.547 | 15.482 | 9.752 | 1.328 |
| tiobe / C# / example ms | 0.764 | 0.261 | 0.256 | 0.252 | 1.147 | 1.781 | 0.176 |
| tiobe / C# / large ms | 11.594 | 3.807 | 3.759 | 3.686 | 17.040 | 27.318 | 2.531 |
| tiobe / JavaScript / example ms | 2.040 | 0.838 | 0.812 | 0.809 | 4.655 | 5.428 | 0.229 |
| tiobe / JavaScript / large ms | 29.641 | 10.682 | 10.525 | 10.558 | 69.914 | 83.184 | 2.402 |
| tiobe / Visual Basic / example ms | 0.240 | 0.239 | 0.239 | 0.234 | 0.968 | 0.320 | 0.049 |
| tiobe / Visual Basic / large ms | 3.747 | 3.802 | 3.834 | 3.767 | 15.260 | 4.968 | 0.764 |
| tiobe / SQL / example ms | 0.273 | 0.249 | 0.239 | 4.306 | 2.453 | 0.430 | 0.077 |
| tiobe / SQL / large ms | 3.839 | 3.678 | 3.681 | 69.172 | 38.322 | 6.016 | 0.990 |
| tiobe / R / example ms | 0.199 | 0.153 | 0.152 | 0.152 | 1.525 | 0.671 | 0.051 |
| tiobe / R / large ms | 2.894 | 2.269 | 2.276 | 2.239 | 23.466 | 10.089 | 0.737 |
| tiobe / Rust / example ms | 0.184 | 0.149 | 0.146 | 0.147 | 1.139 | 0.460 | 0.083 |
| tiobe / Rust / large ms | 2.823 | 2.334 | 2.306 | 2.297 | 18.087 | 6.946 | 1.203 |
| tiobe / Fortran / example ms | 0.450 | 0.342 | 0.355 | 0.329 | 1.583 | 1.007 | 0.064 |
| tiobe / Fortran / large ms | 6.411 | 4.800 | 4.989 | 4.694 | 24.219 | 15.303 | 0.862 |
| tiobe / Go / example ms | 0.329 | 0.211 | 0.205 | 0.197 | 1.235 | 0.530 | 0.058 |
| tiobe / Go / large ms | 4.891 | 3.163 | 3.125 | 2.963 | 18.715 | 7.721 | 0.826 |
| tiobe / Delphi/Object Pascal / example ms | 0.108 | 0.131 | 0.131 | 0.130 | 0.742 | 0.196 | 0.061 |
| tiobe / Delphi/Object Pascal / large ms | 1.687 | 2.157 | 2.140 | 2.135 | 11.585 | 2.937 | 0.953 |
| tiobe / PHP / example ms | 0.283 | 0.173 | 0.168 | 0.167 | 1.587 | 0.584 | 0.122 |
| tiobe / PHP / large ms | 3.941 | 2.465 | 2.454 | 2.436 | 24.535 | 8.383 | 1.664 |
| tiobe / Assembly language / example ms | 0.254 | 0.107 | 0.102 | 0.099 | 2.263 | 0.798 | 0.034 |
| tiobe / Assembly language / large ms | 3.587 | 1.462 | 1.406 | 1.429 | 37.120 | 11.565 | 0.416 |
| tiobe / Ada / example ms | 0.188 | 0.180 | 0.177 | 0.172 | 0.634 | 0.398 | 0.068 |
| tiobe / Ada / large ms | 2.816 | 2.735 | 2.753 | 2.670 | 10.045 | 6.225 | 1.055 |
| tiobe / Swift / example ms | 0.327 | 0.201 | 0.194 | 0.193 | 1.392 | 0.733 | 0.076 |
| tiobe / Swift / large ms | 4.660 | 2.850 | 2.788 | 2.744 | 20.682 | 10.322 | 1.001 |
| tiobe / Objective-C / example ms | 0.347 | 0.188 | 0.184 | 0.180 | 1.705 | 0.743 | 0.068 |
| tiobe / Objective-C / large ms | 5.021 | 2.758 | 2.761 | 2.718 | 26.164 | 11.053 | 0.915 |
| tiobe / COBOL / example ms | 0.702 | 0.679 | 0.670 | 0.670 | 4.311 | 0.593 | 0.073 |
| tiobe / COBOL / large ms | 10.599 | 10.372 | 10.304 | 10.315 | 67.996 | 8.662 | 1.005 |

All required exact native/Shiki HTML checks and regex-mode diagnostics passed. Prism uses independent grammars and has no TextMate parity claim.

