"""Add release-pinned decoded SHA-256 blocks without rebuilding CDN objects.

Usage: python3 add-chunk-pins.py <assets/catalog.json> <decoded-cache-directory>
The Rust asset generator emits these pins for all future grammar updates.
"""
import hashlib
import json
from pathlib import Path
import sys

lock_path, cache = map(Path, sys.argv[1:])
lock = json.loads(lock_path.read_text())
chunk_bytes = 1024 * 1024
count = 0
for asset in lock["release"]["assets"].values():
    decoded = asset.get("decoded")
    if not decoded or decoded["size"] < 4 * chunk_bytes:
        continue
    data = (cache / decoded["sha256"]).read_bytes()
    assert len(data) == decoded["size"]
    assert hashlib.sha256(data).hexdigest() == decoded["sha256"]
    decoded["sha256Chunks"] = [hashlib.sha256(data[i:i + chunk_bytes]).hexdigest()
                              for i in range(0, len(data), chunk_bytes)]
    count += 1
lock_path.write_text(json.dumps(lock, indent=2, ensure_ascii=False) + "\n")
print(f"Added decoded block pins to {count} existing prepared payloads.")
