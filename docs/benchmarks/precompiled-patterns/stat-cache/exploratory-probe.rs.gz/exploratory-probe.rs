use sha2::{Digest, Sha256};
use std::{time::Instant, sync::atomic::{AtomicUsize,Ordering}};
fn main() {
 let bytes=std::fs::read(std::env::args().nth(1).unwrap()).unwrap();
 let pins:Vec<_>=bytes.chunks(1024*1024).map(Sha256::digest).collect();
 for i in 0..25 { let n=[1,2,4,8,16][i%5]; let start=Instant::now();
 let next=AtomicUsize::new(0);
 std::thread::scope(|s| { for _ in 0..n { let bytes=&bytes; let pins=&pins; let next=&next; s.spawn(move || loop {
 let j=next.fetch_add(1,Ordering::Relaxed); if j>=pins.len(){break;} let a=j*1024*1024; let b=(a+1024*1024).min(bytes.len()); assert_eq!(Sha256::digest(&bytes[a..b]),pins[j]);
 }); }});
 println!("{n} {}",start.elapsed().as_secs_f64()*1000.0);
 }
}
