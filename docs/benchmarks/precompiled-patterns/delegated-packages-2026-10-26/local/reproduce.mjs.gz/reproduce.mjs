import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import os from 'node:os';
const root='/private/tmp/ferriki-indexed-20261026';
const repo=process.cwd();
const worker=repo+'/docs/benchmarks/precompiled-patterns/decoded-cache/reproduce.mjs';
const lanes=['before','after'].flatMap(label=>['off','auto','eager','prepared'].map(mode=>({label,mode})));
const input=root+'/inputs.json';
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const run=lane=>{
 const facade=root+(lane.label==='before'?'/facade':'/scoped-facade');
 const addon=root+(lane.label==='before'?'/before.node':'/scoped-after.node');
 const child=spawnSync(process.execPath,[worker,'--worker',facade+'/index.mjs',input,'repository',lane.mode,repo+'/node/.cache/ferriki-assets'],{env:{...process.env,FERRIKI_BENCH_ADDON:addon},encoding:'utf8',timeout:120000});
 assert.equal(child.status,0,child.stderr);
 return {...lane,...JSON.parse(child.stdout)};
};
for(const label of ['before','after'])run({label,mode:'prepared'});
const rows=[];
for(let repeat=0;repeat<5;repeat++){
 for(const lane of [...lanes.slice(repeat),...lanes.slice(0,repeat)]){
  const row={repeat,...run(lane)};
  if(rows.length)assert.deepEqual(row.outputHashes,rows[0].outputHashes);
  rows.push(row);
 }
 console.error('completed rotation '+repeat);
}
writeFileSync(root+'/delegated-paired.json',JSON.stringify({cpu:os.cpus()[0].model,os:os.platform()+' '+os.release(),node:process.version,baselineSha256:hash(readFileSync(root+'/before.node')),candidateSha256:hash(readFileSync(root+'/scoped-after.node')),inputsSha256:hash(readFileSync(input)),rows},null,2)+'\n');
