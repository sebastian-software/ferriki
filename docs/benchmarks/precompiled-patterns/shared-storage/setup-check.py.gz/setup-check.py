import json,os,statistics,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
addons={'baseline':'/private/tmp/ferriki-loading-20261025/stat.node','legacy':str(root/'legacy.node'),'shared':str(root/'shared.node')}
rows=[]
for i in range(20):
 labels=list(addons);offset=i%3
 for label in labels[offset:]+labels[:offset]:
  child=subprocess.run(['node',str(root/'setup-worker.mjs'),'/private/tmp/ferriki-loading-20261025/stat-facade','/private/tmp/ferriki-prepared-load-20261025/inputs.json',str(root/'frozen-cache')],env={**os.environ,'FERRIKI_BENCH_ADDON':addons[label]},capture_output=True,text=True,check=True)
  r={'label':label,'repeat':i,**json.loads(child.stdout)};rows.append(r)
  assert r['diagnostics']['preparedArchives']==0
summary={label:statistics.median(r['setupMs'] for r in rows if r['label']==label) for label in addons}
(root/'setup-check.json').write_text(json.dumps({'summary':summary,'rows':rows},indent=2)+'\n')
print(summary)
