"""Build three isolated native consumers against one shared-storage Ferroni tree."""
import hashlib,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
consumer=root/'consumer';engine=root/'ferroni'

def source_hash(directory):
    h=hashlib.sha256()
    files=list(directory.glob('src/**/*.rs'))+list(directory.glob('crates/*/src/**/*.rs'))
    files += [directory/'Cargo.toml',directory/'Cargo.lock']
    for p in sorted(files):
        h.update(str(p.relative_to(directory)).encode()+b'\0'+p.read_bytes()+b'\0')
    return h.hexdigest()

for lane,kind in [('legacy','base'),('shared','shared'),('mapped','mapped')]:
    files=json.loads((root/f'variants/{kind}.json').read_text())
    for path,content in files.items(): (consumer/path).write_text(content)
    subprocess.run(['cargo','fmt','--all'],cwd=consumer,check=True)
    files={p:(consumer/p).read_text() for p in files}
    (root/f'variants/{kind}.json').write_text(json.dumps(files))
    args=['cargo','build','--offline','--release','-p','ferriki-core','--config',f'patch.crates-io.ferroni.path="{engine}"']
    with (root/f'final-{lane}-build.log').open('w') as log:
        subprocess.run(args,cwd=consumer,check=True,stdout=log,stderr=subprocess.STDOUT)
    artifact=(consumer/'target/release/libferriki_core.dylib').read_bytes()
    (root/f'{lane}.node').write_bytes(artifact)
    receipt={'lane':lane,'binarySha256':hashlib.sha256(artifact).hexdigest(),
             'ferrikiBaseCommit':'04c447e0eeb71d371e2ee0ab08103e6828913efe',
             'ferroniBaseCommit':'1b587fbcc60eaac3828e9d8d4e21e00c066d1aad',
             'consumerSourceSha256':source_hash(consumer),'ferroniSourceSha256':source_hash(engine),
             'cargoArgs':args,'rustc':subprocess.check_output(['rustc','-vV'],text=True),
             'rustflags':os.environ.get('RUSTFLAGS'),'encodedRustflags':os.environ.get('CARGO_ENCODED_RUSTFLAGS'),
             'profile':'consumer ordinary release, fat LTO, one codegen unit',
             'purpose':{'legacy':'shared API with original copying importer','shared':'safe owned-container importer','mapped':'frozen-cache mapping diagnostic'}[lane]}
    (root/f'build-{lane}.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(lane,receipt['binarySha256'],flush=True)
