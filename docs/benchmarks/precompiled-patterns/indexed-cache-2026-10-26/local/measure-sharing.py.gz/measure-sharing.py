from pathlib import Path
import json,struct,hashlib,subprocess
catalog=json.loads(Path('assets/catalog.json').read_text())['languages']['entries']
entries={e['id']:e for e in catalog}
release=json.loads(Path('assets/standard/release-manifest.json').read_text())['assets']
def decoded(lang):
 path=Path('assets/standard/languages')/(lang+'.fkbc')
 return subprocess.run(['zstd','-q','-d','-c',str(path)],stdout=subprocess.PIPE,check=True).stdout

def records(blob):
 view=memoryview(blob)
 version,scope_len,program_len,group_len=struct.unpack_from('<IIQQ',view,8)
 scope_end=32+scope_len;end=scope_end+program_len
 assert bytes(view[:8])==b'FKBC002\0' and end+group_len==len(view)
 assert bytes(view[scope_end:scope_end+8])==b'FERRONI\0'
 assert struct.unpack_from('<I',view,scope_end+8)[0]==2
 index_len,count=struct.unpack_from('<II',view,scope_end+12)
 data_start=scope_end+16+index_len;at=scope_end+20
 programs=[]
 for _ in range(count):
  key_len=struct.unpack_from('<I',view,at)[0];at+=4
  key=bytes(view[at:at+key_len]);at+=key_len
  offset,length,checksum=struct.unpack_from('<III',view,at);at+=12
  programs.append((key,hashlib.sha256(view[data_start+offset:data_start+offset+length]).digest(),length))
 assert at==data_start
 programs.sort()
 key_hashes=[hashlib.sha256(k).digest() for k,_,_ in programs]
 p={hashlib.sha256(key_hashes[i]+body).hexdigest():length for i,(_,body,length) in enumerate(programs)}
 assert bytes(view[end:end+8])==b'FPRT003\0'
 at=end+13;count=struct.unpack_from('<I',view,at)[0];at+=4
 groups={}
 for _ in range(count):
  n=struct.unpack_from('<I',view,at)[0];at+=4
  ids=struct.unpack_from('<'+str(n)+'I',view,at);at+=4*n
  checksum,length=struct.unpack_from('<II',view,at);at+=8
  key=hashlib.sha256(b''.join(key_hashes[i] for i in ids)).digest()
  body=hashlib.sha256(view[at:at+length]).digest();at+=length
  groups[hashlib.sha256(key+body).hexdigest()]=length
 assert at==len(view)
 return p,groups

def dependencies(lang):
 visited=set();pending=[lang]
 while pending:
  name=pending.pop()
  e=entries.get(name)
  if not e or name in visited:continue
  visited.add(name)
  pending.extend(e.get('embedded_langs',[])+e.get('embedded_langs_lazy',[]))
 visited.discard(lang)
 return visited
roots=['markdown','astro','html']
hosts={lang:records(decoded(lang)) for lang in roots}
deps={lang:dependencies(lang) for lang in roots}
matched={lang:[set(),set()] for lang in roots}
for dep in sorted(set.union(*deps.values())):
 if f'languages/{dep}.fkbc' not in release:continue
 data=hosts.get(dep)
 if data is None:data=records(decoded(dep))
 for lang in roots:
  if dep in deps[lang]:
   for i in [0,1]: matched[lang][i].update(hosts[lang][i].keys() & data[i].keys())
 print('checked',dep,flush=True)
rows=[]
for lang in roots:
 programs,groups=hosts[lang];mp,mg=matched[lang]
 rows.append({'language':lang,'dependencies':sorted(deps[lang]),'decodedBytes':release[f'languages/{lang}.fkbc']['decoded']['size'],'compressedBytes':release[f'languages/{lang}.fkbc']['size'],'programCount':len(programs),'programBytes':sum(programs.values()),'sharedProgramCount':len(mp),'sharedProgramBytes':sum(programs[k] for k in mp),'groupCount':len(groups),'groupBytes':sum(groups.values()),'sharedGroupCount':len(mg),'sharedGroupBytes':sum(groups[k] for k in mg)})
Path('/private/tmp/ferriki-indexed-20261026/sharing.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
