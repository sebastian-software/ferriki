import { createRequire } from "node:module";
import process from "node:process";
const require = createRequire(import.meta.url);
export function loadFerrikiNativeBinding() {
  if (!process.env.FERRIKI_BENCH_ADDON) throw new Error("Missing benchmark addon");
  return require(process.env.FERRIKI_BENCH_ADDON);
}
export const tryLoadFerrikiNativeBinding = loadFerrikiNativeBinding;
