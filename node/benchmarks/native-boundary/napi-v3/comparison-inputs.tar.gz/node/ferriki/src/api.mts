export interface LanguageRegistration {
  name: string;
  scopeName: string;
  displayName?: string;
  aliases?: readonly string[];
  patterns?: readonly unknown[];
  repository?: Readonly<Record<string, unknown>>;
  injections?: Readonly<Record<string, unknown>>;
  injectionSelector?: string;
  fileTypes?: readonly string[];
  firstLineMatch?: string;
  embeddedLangs?: readonly string[];
  embeddedLanguages?: readonly string[];
  embeddedLangsLazy?: readonly string[];
  injectTo?: readonly string[];
  balancedBracketSelectors?: readonly string[];
  unbalancedBracketSelectors?: readonly string[];
  foldingStopMarker?: string;
  foldingStartMarker?: string;
}

export interface ThemeRegistration {
  name: string;
  type?: "dark" | "light" | string;
  fg?: string;
  bg?: string;
  settings?: readonly unknown[];
  tokenColors?: readonly unknown[];
  colors?: Readonly<Record<string, string>>;
  include?: string;
  displayName?: string;
  $schema?: string;
  semanticHighlighting?: boolean;
  semanticTokenColors?: Readonly<Record<string, string>>;
}

export type LanguageInput = string | LanguageRegistration;
export type ThemeInput = string | ThemeRegistration;
export type SyncRegistrationInput<T> =
  | T
  | { default: SyncRegistrationInput<T> }
  | readonly SyncRegistrationInput<T>[];
export type RegistrationInput<T> =
  | SyncRegistrationInput<T>
  | PromiseLike<RegistrationInput<T>>
  | (() => RegistrationInput<T>);

/**
 * Where standard grammars and themes come from. Payloads are downloaded from a
 * release-pinned CDN with Node's built-in fetch on first use, verified by
 * SHA-256 and cached. Unset fields fall back to `FERRIKI_ASSETS_REMOTE`,
 * `FERRIKI_ASSETS_BASE_URL` and `FERRIKI_CACHE_DIR`.
 */
export interface AssetOptions {
  /** Allows downloads; `false` loads only cached payloads. Default: `true`. */
  remote?: boolean;
  /** Mirror serving `<commit>/assets/shiki/<path>`. Default: `https://assets.ferriki.dev`. */
  baseUrl?: string;
  /** Cache directory. Default: `node_modules/.cache/ferriki`, then the platform cache. */
  cacheDir?: string;
}

export interface HighlighterOptions {
  langs?: readonly RegistrationInput<LanguageInput>[];
  themes?: readonly RegistrationInput<ThemeInput>[];
  langAlias?: Readonly<Record<string, string>>;
  /** Default hooks. A call's `transformers` replaces these; `[]` disables them. */
  transformers?: readonly ShikiTransformer[];
  assets?: AssetOptions;
}

export interface HighlighterSyncOptions {
  langs?: readonly SyncRegistrationInput<LanguageInput>[];
  themes?: readonly SyncRegistrationInput<ThemeInput>[];
  langAlias?: Readonly<Record<string, string>>;
  /** Default hooks. A call's `transformers` replaces these; `[]` disables them. */
  transformers?: readonly ShikiTransformer[];
  /** A synchronous highlighter never downloads; it loads only cached payloads. */
  assets?: AssetOptions;
}

export interface HighlightOptions {
  lang: LanguageInput;
  /** Nested scope classes; inline styles remain the default. */
  styleMode?: "inline" | "classes";
  theme?: ThemeInput;
  themes?: Readonly<Partial<Record<string, ThemeInput | undefined>>>;
  defaultColor?: string | false;
  cssVariablePrefix?: string;
  /** Includes TextMate scopes or token types in HTML transformer callback tokens. */
  includeExplanation?: boolean | "scopeName" | "tokenType";
  grammarState?: GrammarState;
  mergeWhitespaces?: boolean;
  mergeSameStyleTokens?: boolean;
  rootStyle?: string | false;
  tabindex?: string | number | false | null;
  tokenizeMaxLineLength?: number;
  tokenizeTimeLimit?: number;
  structure?: "classic" | "inline";
  meta?: Readonly<{
    __raw?: string;
    [key: string]: unknown;
  }>;
  data?: Readonly<Record<string, unknown>>;
  transformers?: readonly ShikiTransformer[];
  decorations?: readonly DecorationItem[];
}

export interface HtmlWithCss {
  html: string;
  /** Rules for this result. Combine the CSS from all rendered blocks. */
  css: string;
}

export interface ThemedToken {
  /** Full grammar scope path in classes mode or when requested for callbacks. */
  scopeNames?: readonly string[];
  content: string;
  offset: number;
  htmlAttrs?: Readonly<Record<string, string>>;
  color?: string;
  fontStyle?: number;
  type?: number;
  htmlStyle?: Readonly<Record<string, string>>;
  variants?: Readonly<
    Record<
      string,
      {
        color?: string;
        fontStyle?: number;
      }
    >
  >;
}

export interface GrammarState {
  readonly version: 1;
  readonly lang: string;
  readonly theme: string;
  readonly themes: readonly string[];
  readonly scopes: readonly string[];
  /** Opaque serialized source context used to continue tokenization. */
  readonly source: string;
}

export interface HastText {
  type: "text";
  value: string;
}

export interface HastElement {
  type: "element";
  tagName: string;
  properties: Record<string, unknown>;
  children: HastNode[];
  /** Callback-only metadata from `HighlightOptions.data`; omitted from HTML. */
  data?: Readonly<Record<string, unknown>>;
}

export interface HastRoot {
  type: "root";
  children: HastNode[];
}

export type HastNode = HastRoot | HastElement | HastText;

export interface DecorationItem {
  start: number | { line: number; character: number };
  end: number | { line: number; character: number };
  tagName?: string;
  properties?: Record<string, unknown>;
  transform?: (element: HastElement, type: "wrapper" | "line" | "token") => HastElement | void;
  alwaysWrap?: boolean;
}

export interface ShikiTransformerContextCommon {
  meta: Record<string, unknown>;
  options: HighlightOptions;
}

export interface ShikiTransformerContext extends ShikiTransformerContextCommon {
  readonly source: string;
  readonly tokens: ThemedToken[][];
  readonly root: HastRoot;
  readonly pre: HastElement;
  readonly code: HastElement;
  readonly lines: HastElement[];
  readonly structure: HighlightOptions["structure"];
  addClassToHast: (hast: HastElement, className: string | string[]) => HastElement;
}

export interface ShikiTransformer {
  name?: string;
  enforce?: "pre" | "post";
  preprocess?: (
    this: ShikiTransformerContextCommon,
    code: string,
    options: HighlightOptions,
  ) => string | void;
  tokens?: (
    this: ShikiTransformerContextCommon & { readonly source: string },
    tokens: ThemedToken[][],
  ) => ThemedToken[][] | void;
  root?: (this: ShikiTransformerContext, hast: HastRoot) => HastRoot | void;
  pre?: (this: ShikiTransformerContext, hast: HastElement) => HastElement | void;
  code?: (this: ShikiTransformerContext, hast: HastElement) => HastElement | void;
  line?: (this: ShikiTransformerContext, hast: HastElement, line: number) => HastElement | void;
  span?: (
    this: ShikiTransformerContext,
    hast: HastElement,
    line: number,
    col: number,
    lineElement: HastElement,
    token: ThemedToken,
  ) => HastElement | void;
  postprocess?: (
    this: ShikiTransformerContextCommon,
    html: string,
    options: HighlightOptions,
  ) => string | void;
}

export interface Highlighter {
  codeToHtml: (code: string, options: HighlightOptions) => string;
  codeToHtmlWithCss: (code: string, options: HighlightOptions) => HtmlWithCss;
  getLastGrammarState: {
    (code: string, options: HighlightOptions): GrammarState;
  };
  getLoadedLanguages: () => string[];
  getLoadedThemes: () => string[];
  loadLanguage: (...languages: RegistrationInput<LanguageInput>[]) => Promise<void>;
  loadLanguageSync: (...languages: SyncRegistrationInput<LanguageInput>[]) => void;
  loadTheme: (...themes: RegistrationInput<ThemeInput>[]) => Promise<void>;
  loadThemeSync: (...themes: SyncRegistrationInput<ThemeInput>[]) => void;
  resolveLangAlias: (language: string) => string;
  dispose: () => void;
  [Symbol.dispose]: () => void;
}

export type FerrikiErrorCode =
  | "ERR_USAGE"
  | "ERR_UNSUPPORTED"
  | "ERR_NATIVE_LOAD"
  | "ERR_ASSET"
  | "ERR_RESOURCE_LIMIT"
  | "ERR_INTERNAL";

export declare class ShikiError extends Error {
  readonly code: FerrikiErrorCode;
  constructor(message: string, code?: FerrikiErrorCode, options?: { cause?: unknown });
}

export declare class FerrikiError extends ShikiError {
  constructor(message: string, code?: FerrikiErrorCode, options?: { cause?: unknown });
}

/** Version of the bundled native core, or undefined when no platform binary loads. */
export declare function ferrikiVersion(): string | undefined;

export declare function createHighlighter(options?: HighlighterOptions): Promise<Highlighter>;
export declare const createHighlighterCore: typeof createHighlighter;
export declare const createShikiPrimitiveAsync: typeof createHighlighter;
export declare function createHighlighterCoreSync(options?: HighlighterSyncOptions): Highlighter;
export declare function createShikiPrimitive(options?: HighlighterSyncOptions): Highlighter;

export declare function getSingletonHighlighter(options?: HighlighterOptions): Promise<Highlighter>;
export declare const getSingletonHighlighterCore: typeof getSingletonHighlighter;

/** Renders nested scope classes and extracts styles from unchanged TextMate themes. */
export declare function codeToHtmlWithCss(
  code: string,
  options: HighlightOptions,
): Promise<HtmlWithCss>;
export declare function codeToHtmlWithCss(
  highlighter: Highlighter,
  code: string,
  options: HighlightOptions,
): HtmlWithCss;

export declare function codeToHtml(code: string, options: HighlightOptions): Promise<string>;
export declare function codeToHtml(
  highlighter: Highlighter,
  code: string,
  options: HighlightOptions,
): string;

export declare function getLastGrammarState(
  code: string,
  options: HighlightOptions,
): Promise<GrammarState>;
export declare function getLastGrammarState(
  highlighter: Highlighter,
  code: string,
  options: HighlightOptions,
): GrammarState;
export interface CssVariablesThemeOptions {
  name?: string;
  type?: "dark" | "light" | string;
  variableDefaults?: {
    foreground?: string;
    background?: string;
  };
}

export declare function createCssVariablesTheme(
  options?: CssVariablesThemeOptions,
): ThemeRegistration;
export declare const bundledLanguages: Readonly<
  Record<string, () => Promise<LanguageRegistration[]>>
>;
export declare const bundledThemes: Readonly<Record<string, () => Promise<ThemeRegistration>>>;
export declare const bundledLanguagesAlias: Readonly<Record<string, string>>;
export type BundledLanguage = keyof typeof bundledLanguages;
export type BundledTheme = keyof typeof bundledThemes;
