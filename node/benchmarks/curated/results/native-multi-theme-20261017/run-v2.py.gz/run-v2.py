import pathlib
import subprocess

base = pathlib.Path('/private/tmp/ferriki-independent-perf-20261017/multi')
cwd = '/Users/sebastian/Workspace/.codex/dfa-consumer-bench/ferriki/node'
for label, workers, rounds, cold, extra in [('homepage-v2', 16, 60, 40, []), ('multi-v2', 6, 40, 30, ['--multi'])]:
    args = ['node', 'scripts/bench-independent-paired.mjs',
            '--engine', f'baseline={base}/baseline', '--engine', f'candidate={base}/candidate-v2',
            '--corpus-root', '/private/tmp/ferriki-style-ascii-20261017/published-corpus',
            '--processes', str(workers), '--rounds', str(rounds), '--cold-runs', str(cold),
            '--write', str(base / (label + '.json')), *extra]
    print('START', label, flush=True)
    with (base / (label + '.log')).open('w') as log:
        subprocess.run(args, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True)
    print('END', label, flush=True)
